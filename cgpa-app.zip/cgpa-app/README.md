# CGPA Calculator — Full Stack (Vue + Express + MongoDB)

A CGPA/GPA calculator with a Vue 3 frontend and an Express + MongoDB backend
for persisting calculation history (replacing the original browser
`localStorage` version).

```
cgpa-app/
├── client/   # Vue 3 + Vite frontend
└── server/   # Express + MongoDB (Mongoose) backend
```

## Features

- Add/remove semesters, enter GPA + credit hours, calculate CGPA
- Save calculated results to MongoDB via a REST API
- View, delete, or wipe saved calculation history
- Clean separation between frontend (`client/`) and backend (`server/`)

## Prerequisites

- Node.js 18+
- A MongoDB instance — either local (`mongod`) or a free
  [MongoDB Atlas](https://www.mongodb.com/atlas) cluster

## 1. Backend setup

```bash
cd server
npm install
cp .env.example .env
# edit .env and set your MONGODB_URI
npm run dev
```

The API will start on `http://localhost:5000`. Health check:
`GET http://localhost:5000/api/health`.

### API Endpoints

| Method | Endpoint            | Description                    |
|--------|----------------------|--------------------------------|
| GET    | `/api/records`       | List all saved records         |
| POST   | `/api/records`       | Create a record `{ cgpa, semestersCount }` |
| DELETE | `/api/records/:id`   | Delete a single record          |
| DELETE | `/api/records`       | Delete all records               |

## 2. Frontend setup

In a separate terminal:

```bash
cd client
npm install
npm run dev
```

The app will start on `http://localhost:5173`. In development, Vite proxies
requests to `/api` through to the Express server on port 5000 (see
`client/vite.config.js`), so no extra configuration is needed.

For a production build, set `VITE_API_URL` in `client/.env` to your deployed
backend's base URL (see `client/.env.example`), then run:

```bash
npm run build
```

## Notes on fixes made while adding the backend

- `vue-router` was used in the code but was missing from `package.json`
  dependencies — added it (along with `axios` for API calls).
- Calculation history was stored only in the browser's `localStorage`,
  meaning it was lost across devices/browsers — this is now persisted in
  MongoDB via the Express API.
- Replaced blocking `alert()` calls with inline UI feedback for errors and
  loading/saving states.
- Normalized line endings (CRLF → LF) and formatting across source files.
- Removed an unused leftover Vite scaffold stylesheet that was never
  imported by the app.
