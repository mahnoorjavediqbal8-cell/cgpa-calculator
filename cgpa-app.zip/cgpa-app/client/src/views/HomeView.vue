<template>
  <div class="dashboard-container">
    <div class="header-section">
      <h2>📊 Academic CGPA Dashboard</h2>
      <p>Configure semesters to compute final grade point statistics.</p>
    </div>

    <div class="calculator-card">
      <SemesterTable
        v-for="(semester, index) in semesters"
        :key="index"
        :semester="semester"
        :index="index"
        @update-data="mutateSemesterData"
        @remove-semester="removeSemester"
      />

      <div class="control-buttons">
        <button @click="addSemester" class="btn-secondary" type="button">➕ Add Semester</button>
        <button @click="executeCalculation" class="btn-primary" type="button">🔢 Calculate CGPA</button>
      </div>

      <p v-if="errorMessage" class="error-text">{{ errorMessage }}</p>

      <div v-if="cgpa !== null" class="result-display">
        <p>Cumulative GPA (CGPA)</p>
        <div class="cgpa-value">{{ cgpa }}</div>
        <button @click="persistRecord" class="btn-save" type="button" :disabled="isSaving">
          {{ isSaving ? 'Saving…' : '💾 Save to Server' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import SemesterTable from '../components/SemesterTable.vue'
import { recordsApi } from '../services/api'

const semesters = ref([{ gpa: '', credits: '' }])
const cgpa = ref(null)
const errorMessage = ref('')
const isSaving = ref(false)

const addSemester = () => {
  semesters.value.push({ gpa: '', credits: '' })
}

const removeSemester = (index) => {
  if (semesters.value.length > 1) {
    semesters.value.splice(index, 1)
  }
}

// Handler catching input payload from Child Component Emits
const mutateSemesterData = (index, field, value) => {
  if (value === '') {
    semesters.value[index][field] = ''
  } else {
    semesters.value[index][field] = field === 'gpa' ? parseFloat(value) : parseInt(value, 10)
  }
}

const executeCalculation = () => {
  errorMessage.value = ''
  let accumulatedPoints = 0
  let accumulatedCredits = 0

  semesters.value.forEach((sem) => {
    if (sem.gpa !== '' && sem.credits !== '') {
      accumulatedPoints += sem.gpa * sem.credits
      accumulatedCredits += sem.credits
    }
  })

  if (accumulatedCredits > 0) {
    cgpa.value = (accumulatedPoints / accumulatedCredits).toFixed(2)
  } else {
    cgpa.value = null
    errorMessage.value = 'Incomplete data fields. Please enter GPA and credits for at least one semester.'
  }
}

const persistRecord = async () => {
  if (cgpa.value === null) return
  isSaving.value = true
  errorMessage.value = ''
  try {
    await recordsApi.create({
      cgpa: Number(cgpa.value),
      semestersCount: semesters.value.length,
    })
  } catch (err) {
    errorMessage.value = 'Could not save the record to the server. Please try again.'
    console.error(err)
  } finally {
    isSaving.value = false
  }
}
</script>

<style scoped>
.dashboard-container { max-width: 650px; margin: 0 auto; }
.header-section { text-align: center; margin-bottom: 25px; }
.calculator-card { background: white; border-radius: 12px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
.control-buttons { display: flex; gap: 15px; margin-top: 25px; justify-content: center; }
button { padding: 11px 22px; border: none; border-radius: 6px; font-weight: 600; cursor: pointer; }
button:disabled { opacity: 0.6; cursor: not-allowed; }
.btn-primary { background-color: #d35400; color: white; }
.btn-primary:hover { background-color: #b34500; }
.btn-secondary { background-color: #ecf0f1; color: #2c3e50; }
.btn-secondary:hover { background-color: #bdc3c7; }
.result-display { margin-top: 30px; background: #e8f8f5; border: 2px dashed #a3e4d7; border-radius: 8px; padding: 20px; text-align: center; }
.cgpa-value { font-size: 42px; font-weight: bold; color: #27ae60; margin: 5px 0;}
.btn-save { background-color: #27ae60; color: white; margin-top: 10px; }
.error-text { color: #e74c3c; text-align: center; margin-top: 15px; font-weight: 600; }
</style>
