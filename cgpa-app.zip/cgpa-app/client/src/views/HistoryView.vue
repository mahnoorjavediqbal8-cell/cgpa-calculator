<template>
  <div class="history-container">
    <div class="header-section">
      <h2>📜 Saved Academic Records</h2>
      <p>Tracking dashboard configuration records matrix.</p>
    </div>

    <div v-if="isLoading" class="empty-state">
      <p>Loading records…</p>
    </div>

    <div v-else-if="loadError" class="empty-state">
      <p>{{ loadError }}</p>
      <button @click="fetchRecords" class="btn-redirect">Retry</button>
    </div>

    <div v-else-if="records.length === 0" class="empty-state">
      <div class="empty-icon">📂</div>
      <h3>No Records Present</h3>
      <button @click="$router.push('/')" class="btn-redirect">Return to Engine</button>
    </div>

    <div v-else class="records-grid">
      <HistoryCard
        v-for="(record, index) in records"
        :key="record._id || record.id"
        :record="record"
        :index="index"
        @delete-record="purgeRecord"
      />
      <div class="global-actions">
        <button @click="purgeAll" class="btn-danger-all">Wipe History Logs</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import HistoryCard from '../components/HistoryCard.vue'
import { recordsApi } from '../services/api'

const records = ref([])
const isLoading = ref(true)
const loadError = ref('')

const fetchRecords = async () => {
  isLoading.value = true
  loadError.value = ''
  try {
    records.value = await recordsApi.getAll()
  } catch (err) {
    loadError.value = 'Could not load records from the server.'
    console.error(err)
  } finally {
    isLoading.value = false
  }
}

onMounted(fetchRecords)

const purgeRecord = async (index) => {
  const record = records.value[index]
  if (!record) return
  try {
    await recordsApi.remove(record._id || record.id)
    records.value.splice(index, 1)
  } catch (err) {
    loadError.value = 'Could not delete this record.'
    console.error(err)
  }
}

const purgeAll = async () => {
  if (!confirm('Execute global data factory reset?')) return
  try {
    await recordsApi.removeAll()
    records.value = []
  } catch (err) {
    loadError.value = 'Could not wipe history logs.'
    console.error(err)
  }
}
</script>

<style scoped>
.history-container { max-width: 650px; margin: 0 auto; }
.header-section { text-align: center; margin-bottom: 25px; }
.empty-state { background: white; border-radius: 12px; padding: 40px; text-align: center; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
.empty-icon { font-size: 48px; margin-bottom: 10px; }
.btn-redirect { background-color: #d35400; color: white; margin-top: 15px; padding: 10px 20px; border-radius: 6px; border: none; cursor: pointer; font-weight: bold;}
.records-grid { display: flex; flex-direction: column; gap: 15px; }
.global-actions { text-align: center; margin-top: 20px; }
.btn-danger-all { background-color: #e74c3c; color: white; padding: 11px 22px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold;}
</style>
