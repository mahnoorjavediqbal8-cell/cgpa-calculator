import axios from 'axios'

// In dev, Vite proxies /api to the Express server (see vite.config.js).
// In production, set VITE_API_URL to your deployed backend URL.
const baseURL = import.meta.env.VITE_API_URL || '/api'

const api = axios.create({
  baseURL,
  headers: { 'Content-Type': 'application/json' },
})

export const recordsApi = {
  getAll: () => api.get('/records').then((res) => res.data),
  create: (payload) => api.post('/records', payload).then((res) => res.data),
  remove: (id) => api.delete(`/records/${id}`).then((res) => res.data),
  removeAll: () => api.delete('/records').then((res) => res.data),
}

export default api
