import { Router } from 'express'
import Record from '../models/Record.js'

const router = Router()

// GET /api/records - list all records, most recent first
router.get('/', async (req, res) => {
  try {
    const records = await Record.find().sort({ createdAt: -1 })
    res.json(records)
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch records', error: err.message })
  }
})

// POST /api/records - create a new record
router.post('/', async (req, res) => {
  try {
    const { cgpa, semestersCount } = req.body

    if (cgpa === undefined || semestersCount === undefined) {
      return res.status(400).json({ message: 'cgpa and semestersCount are required' })
    }

    const record = await Record.create({ cgpa, semestersCount })
    res.status(201).json(record)
  } catch (err) {
    res.status(400).json({ message: 'Failed to create record', error: err.message })
  }
})

// DELETE /api/records - wipe all records
router.delete('/', async (req, res) => {
  try {
    await Record.deleteMany({})
    res.json({ message: 'All records deleted' })
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete records', error: err.message })
  }
})

// DELETE /api/records/:id - delete a single record
router.delete('/:id', async (req, res) => {
  try {
    const deleted = await Record.findByIdAndDelete(req.params.id)
    if (!deleted) {
      return res.status(404).json({ message: 'Record not found' })
    }
    res.json({ message: 'Record deleted', id: req.params.id })
  } catch (err) {
    res.status(400).json({ message: 'Failed to delete record', error: err.message })
  }
})

export default router
