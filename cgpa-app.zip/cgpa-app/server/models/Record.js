import mongoose from 'mongoose'

const recordSchema = new mongoose.Schema(
  {
    cgpa: {
      type: Number,
      required: [true, 'cgpa is required'],
      min: 0,
      max: 4,
    },
    semestersCount: {
      type: Number,
      required: [true, 'semestersCount is required'],
      min: 1,
    },
  },
  { timestamps: true } // adds createdAt / updatedAt automatically
)

const Record = mongoose.model('Record', recordSchema)

export default Record
